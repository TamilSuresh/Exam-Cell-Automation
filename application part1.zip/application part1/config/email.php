<?php

$config['protocol']    = 'smtp';
//$config['smtp_host']    = 'ssl://smtp.gmail.com';
$config['smtp_host']    = 'ssl://smtp.googlemail.com';
$config['smtp_port']    = '465';
$config['smtp_timeout'] = '10';
$config['smtp_user']    = 'scripthost3@gmail.com';
//$config['smtp_pass']    = 'abc@123456';
$config['smtp_pass']    = 'ajithlal30';
$config['charset']    = 'utf-8';
$config['newline']    = "\r\n";
$config['mailtype'] = 'html'; // or html
$config['from_name'] = 'TANUVAS'; // or html
$config['from_email'] = 'scripthost3@gmail.com'; // or html